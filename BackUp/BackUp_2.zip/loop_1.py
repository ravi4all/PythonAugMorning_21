'''
start = 0
stop = n - 1 = 5 - 1 = 4
step = +1
'''
for i in range(5):
    print("Hello")

print("Bye")

'''
start = 2
stop = n - 1 = 21 - 1 = 20
step = +2
'''
for i in range(2,21,2):
    print(i)
