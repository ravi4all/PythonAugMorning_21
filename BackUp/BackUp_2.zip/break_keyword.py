for i in range(1,50):
    print(i)
    if i == 10:
        break
