name = input("Enter your name : ")
print("hello",name)

x = int(input("Enter first num : "))
y = int(input("Enter second num : "))
z = x + y
print("Sum is",z)
